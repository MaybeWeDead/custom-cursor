package dev.cursor

import android.os.Binder
import android.os.IBinder
import android.os.Parcel
import android.os.ParcelFileDescriptor
import org.lsposed.hiddenapibypass.HiddenApiBypass
import java.lang.reflect.InvocationTargetException

/**
 * Запускается Shizuku в отдельном процессе под uid shell.
 * Только там системный сервис overlay виден (обычному приложению SELinux его не отдаёт).
 */
class CursorService : Binder() {
    init {
        try { HiddenApiBypass.addHiddenApiExemptions("L") } catch (_: Throwable) {}
    }

    override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
        if (code != 1 && code != 2) return super.onTransact(code, data, reply, flags)
        try {
            if (code == 1) {
                val names = data.createStringArray()!!.toList()
                val pfd = ParcelFileDescriptor.CREATOR.createFromParcel(data)
                try { Shell.apply(pfd, names) } finally { pfd.close() }
            } else {
                Shell.remove()
            }
            reply?.writeInt(0)
        } catch (t: Throwable) {
            reply?.writeInt(1)
            reply?.writeString(describe(t))
        }
        return true
    }

    private fun describe(e: Throwable): String {
        var c: Throwable = e
        while (c is InvocationTargetException && c.targetException != null) c = c.targetException!!
        val frames = c.stackTrace.take(6).joinToString("\n") {
            "  at ${it.className.substringAfterLast('.')}.${it.methodName}:${it.lineNumber}"
        }
        return "[service] ${c.javaClass.simpleName}: ${c.message}\n$frames"
    }
}

internal object Shell {
    private const val NAME = "customcursor"
    private const val TARGET = "android"

    private fun owner() = if (android.os.Process.myUid() == 0) "root" else "com.android.shell"
    private fun userId() = android.os.Process.myUid() / 100000
    private fun cls(n: String) = Class.forName(n)

    private fun overlayManager(): Any {
        val b = cls("android.os.ServiceManager").getMethod("getService", String::class.java)
            .invoke(null, "overlay") as? IBinder ?: error("Сервис overlay недоступен")
        return cls("android.content.om.IOverlayManager\$Stub")
            .getMethod("asInterface", IBinder::class.java).invoke(null, b)!!
    }

    private fun commit(tb: Any) {
        val tCls = cls("android.content.om.OverlayManagerTransaction\$Builder")
        val tx = tCls.getMethod("build").invoke(tb)!!
        cls("android.content.om.IOverlayManager")
            .getMethod("commit", cls("android.content.om.OverlayManagerTransaction"))
            .invoke(overlayManager(), tx)
    }

    fun apply(pfd: ParcelFileDescriptor, names: List<String>) {
        val bCls = cls("android.content.om.FabricatedOverlay\$Builder")
        val builder = bCls.getConstructor(String::class.java, String::class.java, String::class.java)
            .newInstance(owner(), NAME, TARGET)
        val setFile = bCls.methods.firstOrNull {
            it.name == "setResourceValue" && it.parameterTypes.size == 3 &&
                it.parameterTypes[1] == ParcelFileDescriptor::class.java
        } ?: error("В этой версии Android нет setResourceValue(…, ParcelFileDescriptor, …)")

        for (n in names) setFile.invoke(builder, "$TARGET:drawable/$n", pfd, null)
        val overlay = bCls.getMethod("build").invoke(builder)!!
        val id = overlay.javaClass.getMethod("getIdentifier").invoke(overlay)!!

        val tCls = cls("android.content.om.OverlayManagerTransaction\$Builder")
        val tb = tCls.getConstructor().newInstance()
        tCls.getMethod("registerFabricatedOverlay", overlay.javaClass).invoke(tb, overlay)
        tCls.methods.first { it.name == "setEnabled" && it.parameterTypes.size == 3 }
            .invoke(tb, id, true, userId())
        commit(tb)
    }

    fun remove() {
        val id = cls("android.content.om.OverlayIdentifier")
            .getConstructor(String::class.java, String::class.java)
            .newInstance(owner(), NAME)
        val tCls = cls("android.content.om.OverlayManagerTransaction\$Builder")
        val tb = tCls.getConstructor().newInstance()
        tCls.getMethod("unregisterFabricatedOverlay", id.javaClass).invoke(tb, id)
        commit(tb)
    }
}
