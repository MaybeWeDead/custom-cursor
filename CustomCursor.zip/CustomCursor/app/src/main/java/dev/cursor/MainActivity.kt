package dev.cursor

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.Shizuku
import java.io.File
import java.lang.reflect.InvocationTargetException

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private var picked: Uri? = null

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        log(if (result == PackageManager.PERMISSION_GRANTED) "Shizuku: доступ выдан, жми «Применить»" else "Shizuku: доступ отклонён")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        HiddenApiBypass.addHiddenApiExemptions("L")
        Shizuku.addRequestPermissionResultListener(permListener)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        status = TextView(this).apply { textSize = 16f }
        logView = TextView(this).apply { textSize = 12f; setTextIsSelectable(true) }

        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        root.addView(status)
        root.addView(btn("Выбрать курсор (.cur / .ani / .png)") { pick() })
        root.addView(btn("Применить") { applyCursor() })
        root.addView(btn("Вернуть стандартный") { removeCursor() })
        root.addView(btn("Обновить курсор в системе") { refresh() })
        root.addView(TextView(this).apply {
            text = "Размер берётся из файла как есть. Если курсор не сменился сразу — жми «Обновить курсор в системе» или поменяй размер указателя в настройках."
            textSize = 12f
        })
        root.addView(ScrollView(this).apply {
            addView(logView)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        })
        setContentView(root)
        updateStatus()
    }

    override fun onResume() { super.onResume(); updateStatus() }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }

    private fun updateStatus() {
        status.text = when {
            !Shizuku.pingBinder() -> "Shizuku не запущен"
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> "Shizuku: готово"
            else -> "Shizuku запущен, нужен доступ"
        }
    }

    private fun log(s: String) = runOnUiThread { logView.append(s + "\n") }

    private fun ensureShizuku(): Boolean {
        if (!Shizuku.pingBinder()) { log("Shizuku не запущен. Запусти его (беспроводная отладка) и вернись."); return false }
        if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) return true
        Shizuku.requestPermission(1)
        log("Разреши доступ в окне Shizuku и нажми кнопку ещё раз")
        return false
    }

    private fun pick() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }, 42)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK) {
            picked = data?.data
            log("Файл выбран: $picked")
        }
    }

    private fun prepareFile(): File? {
        val uri = picked ?: run { log("Сначала выбери файл"); return null }
        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: run { log("Не смог прочитать файл"); return null }
        val r = try { CursorDecoder.decode(bytes) } catch (e: Throwable) {
            log("Не смог разобрать файл: ${msg(e)}"); return null
        }
        val out = File(cacheDir, "cursor.png")
        out.outputStream().use { r.bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        log("Курсор ${r.bitmap.width}x${r.bitmap.height} (${r.note})")
        if (r.hotX > 4 || r.hotY > 4)
            log("Внимание: hotspot в файле (${r.hotX},${r.hotY}), а система берёт свой — клик может попадать со смещением")
        return out
    }

    private fun applyCursor() {
        if (!ensureShizuku()) return
        val file = prepareFile() ?: return
        Thread {
            try {
                val names = OverlayCtl.scanArrowDrawables()
                log("Ресурсы: $names")
                OverlayCtl.apply(file, names)
                log("Оверлей применён")
                try { OverlayCtl.refreshPointer(this); log("Указатель обновлён") }
                catch (e: Throwable) { log("Автообновление не вышло: ${msg(e)}") }
            } catch (e: Throwable) { log("ОШИБКА: ${msg(e)}") }
        }.start()
    }

    private fun removeCursor() {
        if (!ensureShizuku()) return
        Thread {
            try {
                OverlayCtl.remove(); log("Оверлей удалён")
                try { OverlayCtl.refreshPointer(this) } catch (_: Throwable) {}
            } catch (e: Throwable) { log("ОШИБКА: ${msg(e)}") }
        }.start()
    }

    private fun refresh() {
        if (!ensureShizuku()) return
        Thread {
            try { OverlayCtl.refreshPointer(this); log("Указатель обновлён") }
            catch (e: Throwable) { log("ОШИБКА: ${msg(e)}") }
        }.start()
    }

    private fun msg(e: Throwable): String {
        val c = if (e is InvocationTargetException) e.targetException ?: e else e
        return "${c.javaClass.simpleName}: ${c.message}"
    }
}
