package dev.cursor

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.os.IBinder
import android.os.Parcel
import android.os.ParcelFileDescriptor
import android.provider.Settings
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Клиентская часть: общается с CursorService, который крутится под shell через Shizuku. */
object OverlayCtl {
    @Volatile private var svc: IBinder? = null

    private fun userId() = android.os.Process.myUid() / 100000
    private fun cls(n: String) = Class.forName(n)

    private fun service(ctx: Context): IBinder {
        svc?.takeIf { it.pingBinder() }?.let { return it }
        val latch = CountDownLatch(1)
        val conn = object : ServiceConnection {
            override fun onServiceConnected(n: ComponentName, b: IBinder) { svc = b; latch.countDown() }
            override fun onServiceDisconnected(n: ComponentName) { svc = null }
        }
        val args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, CursorService::class.java.name))
            .processNameSuffix("cursor").debuggable(false).version(1)
        Shizuku.bindUserService(args, conn)
        if (!latch.await(15, TimeUnit.SECONDS)) error("Сервис Shizuku не запустился за 15 секунд")
        return svc!!
    }

    private fun call(ctx: Context, code: Int, fill: (Parcel) -> Unit) {
        val b = service(ctx)
        val d = Parcel.obtain()
        val r = Parcel.obtain()
        try {
            fill(d)
            b.transact(code, d, r, 0)
            if (r.readInt() != 0) error(r.readString() ?: "Ошибка в сервисе")
        } finally {
            d.recycle(); r.recycle()
        }
    }

    /** Имена drawable-ресурсов системного указателя-стрелки. */
    fun scanArrowDrawables(): List<String> {
        val found = try {
            cls("com.android.internal.R\$drawable").declaredFields
                .map { it.name }.filter { it.startsWith("pointer_arrow") }
        } catch (e: Throwable) {
            emptyList()
        }
        return found.ifEmpty { listOf("pointer_arrow_icon", "pointer_arrow_large_icon") }
    }

    fun apply(ctx: Context, png: File, names: List<String>) {
        val pfd = ParcelFileDescriptor.open(png, ParcelFileDescriptor.MODE_READ_ONLY)
        try {
            call(ctx, 1) { d ->
                d.writeStringArray(names.toTypedArray())
                pfd.writeToParcel(d, 0)
            }
        } finally {
            pfd.close()
        }
    }

    fun remove(ctx: Context) = call(ctx, 2) { }

    /** Даём себе WRITE_SECURE_SETTINGS и дёргаем «большой указатель», чтобы система перечитала иконки. */
    fun refreshPointer(ctx: Context) {
        val pm = cls("android.content.pm.IPackageManager\$Stub")
            .getMethod("asInterface", IBinder::class.java)
            .invoke(null, ShizukuBinderWrapper(SystemServiceHelper.getSystemService("package")))!!
        cls("android.content.pm.IPackageManager").methods
            .first { it.name == "grantRuntimePermission" }
            .invoke(pm, ctx.packageName, "android.permission.WRITE_SECURE_SETTINGS", userId())

        val key = "accessibility_large_pointer_icon"
        val r = ctx.contentResolver
        val cur = Settings.Secure.getInt(r, key, 0)
        Settings.Secure.putInt(r, key, 1 - cur)
        Thread.sleep(400)
        Settings.Secure.putInt(r, key, cur)
    }
}
