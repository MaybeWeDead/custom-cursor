package dev.cursor

import android.content.Context
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.provider.Settings
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.io.File

/** Всё через рефлексию: скрытые классы android.content.om.* + Shizuku binder. */
object OverlayCtl {
    private const val NAME = "customcursor"
    private const val TARGET = "android"

    private fun owner() = if (Shizuku.getUid() == 0) "root" else "com.android.shell"
    private fun userId() = android.os.Process.myUid() / 100000

    private fun cls(n: String) = Class.forName(n)

    private fun overlayManager(): Any {
        val b = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("overlay"))
        return cls("android.content.om.IOverlayManager\$Stub")
            .getMethod("asInterface", IBinder::class.java).invoke(null, b)!!
    }

    /** Имена drawable-ресурсов системного указателя-стрелки. */
    fun scanArrowDrawables(): List<String> {
        val found = try {
            cls("com.android.internal.R\$drawable").declaredFields
                .map { it.name }.filter { it.startsWith("pointer_arrow") }
        } catch (e: Throwable) {
            emptyList()
        }
        return found.ifEmpty { listOf("pointer_arrow_icon", "pointer_arrow_large_icon") }
    }

    private fun commit(tb: Any) {
        val tCls = cls("android.content.om.OverlayManagerTransaction\$Builder")
        val tx = tCls.getMethod("build").invoke(tb)!!
        cls("android.content.om.IOverlayManager")
            .getMethod("commit", cls("android.content.om.OverlayManagerTransaction"))
            .invoke(overlayManager(), tx)
    }

    fun apply(png: File, names: List<String>) {
        val bCls = cls("android.content.om.FabricatedOverlay\$Builder")
        val builder = bCls.getConstructor(String::class.java, String::class.java, String::class.java)
            .newInstance(owner(), NAME, TARGET)
        val setFile = bCls.methods.firstOrNull {
            it.name == "setResourceValue" && it.parameterTypes.size == 3 &&
                it.parameterTypes[1] == ParcelFileDescriptor::class.java
        } ?: error("В этой версии Android нет setResourceValue(…, ParcelFileDescriptor, …)")

        val pfd = ParcelFileDescriptor.open(png, ParcelFileDescriptor.MODE_READ_ONLY)
        try {
            for (n in names) setFile.invoke(builder, "$TARGET:drawable/$n", pfd, null)
            val overlay = bCls.getMethod("build").invoke(builder)!!
            val id = overlay.javaClass.getMethod("getIdentifier").invoke(overlay)!!

            val tCls = cls("android.content.om.OverlayManagerTransaction\$Builder")
            val tb = tCls.getConstructor().newInstance()
            tCls.getMethod("registerFabricatedOverlay", overlay.javaClass).invoke(tb, overlay)
            tCls.methods.first { it.name == "setEnabled" && it.parameterTypes.size == 3 }
                .invoke(tb, id, true, userId())
            commit(tb)
        } finally {
            pfd.close()
        }
    }

    fun remove() {
        val id = cls("android.content.om.OverlayIdentifier")
            .getConstructor(String::class.java, String::class.java)
            .newInstance(owner(), NAME)
        val tCls = cls("android.content.om.OverlayManagerTransaction\$Builder")
        val tb = tCls.getConstructor().newInstance()
        tCls.getMethod("unregisterFabricatedOverlay", id.javaClass).invoke(tb, id)
        commit(tb)
    }

    /** Даём себе WRITE_SECURE_SETTINGS и дёргаем «большой указатель», чтобы система перечитала иконки. */
    fun refreshPointer(ctx: Context) {
        val pm = cls("android.content.pm.IPackageManager\$Stub")
            .getMethod("asInterface", IBinder::class.java)
            .invoke(null, ShizukuBinderWrapper(SystemServiceHelper.getSystemService("package")))!!
        cls("android.content.pm.IPackageManager").methods
            .first { it.name == "grantRuntimePermission" }
            .invoke(pm, ctx.packageName, "android.permission.WRITE_SECURE_SETTINGS", userId())

        val key = "accessibility_large_pointer_icon"
        val r = ctx.contentResolver
        val cur = Settings.Secure.getInt(r, key, 0)
        Settings.Secure.putInt(r, key, 1 - cur)
        Thread.sleep(400)
        Settings.Secure.putInt(r, key, cur)
    }
}
