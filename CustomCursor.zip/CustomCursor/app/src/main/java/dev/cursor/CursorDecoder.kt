package dev.cursor

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Превращает .cur / .ani / png / ico в Bitmap. Размер не меняется. */
object CursorDecoder {
    class Result(val bitmap: Bitmap, val hotX: Int, val hotY: Int, val note: String)

    fun decode(d: ByteArray): Result {
        val b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
        return when {
            d.size > 12 && tag(d, 0) == "RIFF" && tag(d, 8) == "ACON" ->
                decodeCur(firstAniFrame(d), ".ani: взят первый кадр")
            d.size > 6 && b.getShort(0).toInt() == 0 && b.getShort(2).toInt() == 2 ->
                decodeCur(d, ".cur")
            else -> {
                val bmp = BitmapFactory.decodeByteArray(d, 0, d.size)
                    ?: error("Неизвестный формат файла")
                Result(bmp, 0, 0, "картинка")
            }
        }
    }

    private fun tag(d: ByteArray, o: Int) = String(d, o, 4, Charsets.US_ASCII)

    /** В .ani кадры лежат в LIST/fram как чанки 'icon', каждый — обычный .cur. */
    private fun firstAniFrame(d: ByteArray): ByteArray {
        val b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
        var p = 12
        while (p + 8 <= d.size) {
            val id = tag(d, p)
            val sz = b.getInt(p + 4)
            if (id == "LIST" && p + 12 <= d.size && tag(d, p + 8) == "fram") {
                var q = p + 12
                val end = minOf(d.size, p + 8 + sz)
                while (q + 8 <= end) {
                    val cid = tag(d, q)
                    val csz = b.getInt(q + 4)
                    if (cid == "icon") return d.copyOfRange(q + 8, q + 8 + csz)
                    q += 8 + csz + (csz and 1)
                }
            }
            p += 8 + sz + (sz and 1)
        }
        error("В .ani не нашёл кадров")
    }

    /** Берём самое большое изображение из .cur, упаковываем в одиночный .ico — такой формат Android читает сам. */
    private fun decodeCur(d: ByteArray, note: String): Result {
        val b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
        val count = b.getShort(4).toInt() and 0xFFFF
        var best = -1
        var bestArea = -1
        for (i in 0 until count) {
            val o = 6 + i * 16
            val w = (d[o].toInt() and 0xFF).let { if (it == 0) 256 else it }
            val h = (d[o + 1].toInt() and 0xFF).let { if (it == 0) 256 else it }
            if (w * h > bestArea) { bestArea = w * h; best = i }
        }
        if (best < 0) error("Пустой .cur")

        val o = 6 + best * 16
        val hx = b.getShort(o + 4).toInt() and 0xFFFF
        val hy = b.getShort(o + 6).toInt() and 0xFFFF
        val size = b.getInt(o + 8)
        val off = b.getInt(o + 12)

        val ico = ByteArray(22 + size)
        val ob = ByteBuffer.wrap(ico).order(ByteOrder.LITTLE_ENDIAN)
        ob.putShort(0, 0); ob.putShort(2, 1); ob.putShort(4, 1)
        System.arraycopy(d, o, ico, 6, 4)
        ob.putShort(10, 1); ob.putShort(12, 32)
        ob.putInt(14, size); ob.putInt(18, 22)
        System.arraycopy(d, off, ico, 22, size)

        val bmp = BitmapFactory.decodeByteArray(ico, 0, ico.size)
            ?: error("Не смог декодировать кадр курсора")
        return Result(bmp, hx, hy, note)
    }
}
